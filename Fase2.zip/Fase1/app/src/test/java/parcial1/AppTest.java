package parcial1;

import parcial1.Model.Criptomoneda;
import parcial1.Services.SimulacionMercado;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class AppTest {
    public static void main(String[] args) {
     
    }
}

